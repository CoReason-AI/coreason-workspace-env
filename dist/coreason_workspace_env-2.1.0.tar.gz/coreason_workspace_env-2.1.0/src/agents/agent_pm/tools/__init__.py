# Placeholder for @tool skills
